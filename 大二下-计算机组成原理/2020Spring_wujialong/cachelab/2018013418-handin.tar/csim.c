// wujialong 2018013418
// TODO: getopt
#include "cachelab.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void printHelp(){
    printf("Usage: ./csim [-hv] -s <num> -E <num> -b <num> -t <file>\n");
    printf("Options:\n");
    printf("  -h         Print this help message.\n");
    printf("  -v         Optional verbose flag.\n");
    printf("  -s <num>   Number of set index bits.\n");
    printf("  -E <num>   Number of lines per set.\n");
    printf("  -b <num>   Number of block offset bits.\n");
    printf("  -t <file>  Trace file.\n");
    printf("\n");
    printf("Examples:\n");
    printf("  linux>  ./csim -s 4 -E 1 -b 4 -t traces/yi.trace\n");
    printf("  linux>  ./csim -v -s 8 -E 2 -b 4 -t traces/yi.trace\n");
}

int s=-1, E=-1, b=-1;
char tracefile[100]={};
int verbose = 0;
int clk=0; // clock
int hits=0, misses=0, evictions=0;


void access(long long addr, int **tag, int **last){
    int group = (addr>>b)&((1<<s)-1);
    int thisTag = addr>>(b+s);
    int line=-1;
    for (int j=0;j<E;j++)
        if (tag[group][j]==thisTag)
            line = j;
    if (line!=-1){
        last[group][line] = clk;
        hits++;
        if (verbose) printf("hit ");
    }else{
        misses++;
        if (verbose) printf("miss ");

        int LRU = -1;
        for (int j=0;j<E;j++){
            if (tag[group][j]==-1){
                LRU=j; break;
            }
            if (LRU==-1 || (clk-last[group][j])>(clk-last[group][LRU]))
                LRU=j;
        }
        if (tag[group][LRU]!=-1){
            evictions++;
            if (verbose) printf("eviction ");
        }
        tag[group][LRU]=thisTag;
        last[group][LRU]=clk;
    }
}

int main(int argc, char* argv[])
{
    for (int i = 1; i < argc; i++)
        if (!strcmp(argv[i], "-s")){
            s = atoi(argv[i+1]);
        } else if (!strcmp(argv[i], "-E")){
            E = atoi(argv[i+1]);
        } else if (!strcmp(argv[i], "-b")){
            b = atoi(argv[i+1]);
        } else if (!strcmp(argv[i], "-t")){
            strcpy(tracefile, argv[i+1]);
        } else {
            if (strchr(argv[i], 'h')){
                printHelp();
                return 0;
            }
            if (strchr(argv[i], 'v')){
                verbose = 1;
            }
        }
    if (s==-1 || E==-1 || b==-1 || !strlen(tracefile)){
        printf("Missing required command line argument\n");
        return 0;
    }

    int **tag = (int**)malloc(sizeof(int*)*(1<<s));
    int **last = (int**)malloc(sizeof(int*)*(1<<s));
    for (int i=0;i<(1<<s);i++){
        tag[i] = (int*)malloc(sizeof(int)*E);
        last[i] = (int*)malloc(sizeof(int)*E);
        for (int j=0;j<E;j++){
            tag[i][j]=last[i][j]=-1;
        }
    }

    FILE* fp; fp=fopen(tracefile,"r");

    char cmd; long long addr; int size;

    while (1){
        do{
            cmd = fgetc(fp);
        }while (cmd!='I' && cmd!='L' && cmd!='S' && cmd!='M' && cmd!=EOF);
        if (cmd==EOF) break;
        if (fscanf(fp, "%llx,%d", &addr, &size)==EOF) break;

        if (cmd=='I') continue;

        if (verbose){
            printf("%c %llx,%d ", cmd, addr, size);
        }

        access(addr, tag, last);
        if (cmd=='M')
            access(addr, tag, last);
        clk++;

        if (verbose){
            printf("\n");
        }
    }

    fclose(fp);
    printSummary(hits, misses, evictions);
    return 0;
}
