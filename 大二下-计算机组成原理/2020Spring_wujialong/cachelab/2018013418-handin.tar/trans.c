/* wujialong 2018013418
 *
 * trans.c - Matrix transpose B = A^T
 *
 * Each transpose function must have a prototype of the form:
 * void trans(int M, int N, int A[N][M], int B[M][N]);
 *
 * A transpose function is evaluated by counting the number of misses
 * on a 1KB direct mapped cache with a block size of 32 bytes.
 */ 
#include <stdio.h>
#include "cachelab.h"

int is_transpose(int M, int N, int A[N][M], int B[M][N]);

/* 
 * transpose_submit - This is the solution transpose function that you
 *     will be graded on for Part B of the assignment. Do not change
 *     the description string "Transpose submission", as the driver
 *     searches for that string to identify the transpose function to
 *     be graded. 
 */

char transpose_submit_desc[] = "Transpose submission";
void transpose_submit(int M, int N, int A[N][M], int B[M][N])
{
    int i,j,r,c;
    int a,b,d,e,f,g,h;
//     fprintf(stderr, "%llx %llx\n", (long long int)&A[0][0], (long long int)&B[0][0]);
    
    if (M==32 && N==32){
        // misses=259 = 3+4*4*16
        for (i=0; i<N; i+=8)
            for (j=0; j<M; j+=8){
                for (r=0; r<8; r++){
                    a=A[i+r][j]; b=A[i+r][j+1]; c=A[i+r][j+2]; d=A[i+r][j+3];
                    e=A[i+r][j+4]; f=A[i+r][j+5]; g=A[i+r][j+6]; h=A[i+r][j+7];
                    
                    B[j+r][i]=a; B[j+r][i+1]=b; B[j+r][i+2]=c; B[j+r][i+3]=d; 
                    B[j+r][i+4]=e; B[j+r][i+5]=f; B[j+r][i+6]=g; B[j+r][i+7]=h;
                }
                for (r=0; r<8; r++)
                    for (c=0; c<r; c++){
                        d=B[j+r][i+c]; B[j+r][i+c]=B[j+c][i+r]; B[j+c][i+r]=d;
                    }
            }
        return;
    }
    
    if (M==64 && N==64){
        // misses=1259 = 3+24*8+19*56
        for (i=0; i<N; i+=8)
            for (j=0; j<M; j+=8){
                if (i!=j){
                    e=A[i][j+4]; f=A[i][j+5]; g=A[i][j+6]; h=A[i][j+7];
                    for (r=i; r<i+8; r++) {
                        a=A[r][j]; b=A[r][j+1]; c=A[r][j+2]; d=A[r][j+3];
                        B[j][r]=a; B[j+1][r]=b; B[j+2][r]=c; B[j+3][r]=d;
                    }
                    for (r=i+7; r>i; r--) {
                        a=A[r][j+4]; b=A[r][j+5]; c=A[r][j+6]; d=A[r][j+7];
                        B[j+4][r]=a; B[j+5][r]=b; B[j+6][r]=c; B[j+7][r]=d;
                    }
                    B[j+4][i]=e; B[j+5][i]=f; B[j+6][i]=g; B[j+7][i]=h;
                }else{
                    // Block = [[X,Y],[Z,W]], totally miss+=24
                    // move X and Y: miss+=8
                    for (r=0; r<4; r++){
                        a=A[i+r][j]; b=A[i+r][j+1]; c=A[i+r][j+2]; d=A[i+r][j+3];
                        e=A[i+r][j+4]; f=A[i+r][j+5]; g=A[i+r][j+6]; h=A[i+r][j+7];

                        B[j+r][i]=a; B[j+r][i+1]=b; B[j+r][i+2]=c; B[j+r][i+3]=d; 
                        B[j+r][i+4]=e; B[j+r][i+5]=f; B[j+r][i+6]=g; B[j+r][i+7]=h;
                    }
                    // transpose X: miss+=0
                    for (r=0; r<4; r++)
                        for (c=0; c<r; c++){
                            a=B[j+r][i+c]; B[j+r][i+c]=B[j+c][i+r]; B[j+c][i+r]=a;
                        }
                    // transpose Y: miss+=0
                    for (r=0; r<4; r++)
                        for (c=0;c<r;c++){
                            a=B[j+r][i+4+c]; B[j+r][i+4+c]=B[j+c][i+4+r]; B[j+c][i+4+r]=a;
                        }
                    
                    // move Z and W: miss+=8
                    for (r=4; r<8; r++){
                        a=A[i+r][j]; b=A[i+r][j+1]; c=A[i+r][j+2]; d=A[i+r][j+3];
                        e=A[i+r][j+4]; f=A[i+r][j+5]; g=A[i+r][j+6]; h=A[i+r][j+7];

                        B[j+r][i]=a; B[j+r][i+1]=b; B[j+r][i+2]=c; B[j+r][i+3]=d; 
                        B[j+r][i+4]=e; B[j+r][i+5]=f; B[j+r][i+6]=g; B[j+r][i+7]=h;
                    }
                    // transpose Z: miss+=0
                    for (r=0; r<4; r++)
                        for (c=0; c<r; c++){
                            a=B[j+4+r][i+c]; B[j+4+r][i+c]=B[j+4+c][i+r]; B[j+4+c][i+r]=a;
                        }
                    // transpose W: miss+=0
                    for (r=0; r<4; r++)
                        for (c=0; c<r; c++){
                            a=B[j+4+r][i+4+c]; B[j+4+r][i+4+c]=B[j+4+c][i+4+r]; B[j+4+c][i+4+r]=a;
                        }

                    // swap Y^T and Z^T
                    for (c=0; c<4; c++){
                        a=B[j+4][i+c]; B[j+4][i+c]=B[j+5][i+c]; B[j+5][i+c]=a;
                    } // miss+=0
                    a=B[j+5][i]; b=B[j+5][i+1]; c=B[j+5][i+2]; d=B[j+5][i+3]; // miss+=0
                    e=B[j][i+4]; f=B[j][i+5]; g=B[j][i+6]; h=B[j][i+7]; //miss+=1
                    B[j+5][i]=e; B[j+5][i+1]=f; B[j+5][i+2]=g; B[j+5][i+3]=h; // miss+=0
                    B[j][i+4]=a; B[j][i+5]=b; B[j][i+6]=c; B[j][i+7]=d; // miss+=0
                    
                    a=B[j+4][i]; b=B[j+4][i+1]; c=B[j+4][i+2]; d=B[j+4][i+3]; // miss+=1
                    e=B[j+1][i+4]; f=B[j+1][i+5]; g=B[j+1][i+6]; h=B[j+1][i+7]; // miss+=1
                    B[j+4][i]=e; B[j+4][i+1]=f; B[j+4][i+2]=g; B[j+4][i+3]=h; // miss+=0
                    B[j+1][i+4]=a; B[j+1][i+5]=b; B[j+1][i+6]=c; B[j+1][i+7]=d; // miss+=0
                    for (c=0; c<4; c++){
                        a=B[j+4][i+c]; B[j+4][i+c]=B[j+5][i+c]; B[j+5][i+c]=a;
                    } // miss+=1
                    
                    for (c=0; c<4; c++){
                        a=B[j+6][i+c]; B[j+6][i+c]=B[j+7][i+c]; B[j+7][i+c]=a;
                    } // miss+=0
                    a=B[j+7][i]; b=B[j+7][i+1]; c=B[j+7][i+2]; d=B[j+7][i+3]; // miss+=0
                    e=B[j+2][i+4]; f=B[j+2][i+5]; g=B[j+2][i+6]; h=B[j+2][i+7]; //miss+=1
                    B[j+7][i]=e; B[j+7][i+1]=f; B[j+7][i+2]=g; B[j+7][i+3]=h; // miss+=0
                    B[j+2][i+4]=a; B[j+2][i+5]=b; B[j+2][i+6]=c; B[j+2][i+7]=d; // miss+=0
                    
                    a=B[j+6][i]; b=B[j+6][i+1]; c=B[j+6][i+2]; d=B[j+6][i+3]; // miss+=1
                    e=B[j+3][i+4]; f=B[j+3][i+5]; g=B[j+3][i+6]; h=B[j+3][i+7]; // miss+=1
                    B[j+6][i]=e; B[j+6][i+1]=f; B[j+6][i+2]=g; B[j+6][i+3]=h; // miss+=0
                    B[j+3][i+4]=a; B[j+3][i+5]=b; B[j+3][i+6]=c; B[j+3][i+7]=d; // miss+=0
                    for (c=0; c<4; c++){
                        a=B[j+6][i+c]; B[j+6][i+c]=B[j+7][i+c]; B[j+7][i+c]=a;
                    } // miss+=1
                }
            }
        return;
    }
    
    if (M==61 && N==67){
        for (i=0;i<N;i+=8)
            for (j=0;j<M;j+=8){
                // misses=1931
//                 for (c=j;c<j+8 && c<M;c++)
//                     for (r=i;r<i+8 && r<N;r++)
//                         B[c][r] = A[r][c];
                
                // misses=1755
                for (r=j;r<j+8 && r<M;r++){
                    a=A[i][r]; b=A[i+1][r]; c=A[i+2][r]; 
                    if (i<64){
                        d=A[i+3][r]; e=A[i+4][r]; f=A[i+5][r]; g=A[i+6][r]; h=A[i+7][r];
                    }

                    B[r][i]=a; B[r][i+1]=b; B[r][i+2]=c; 
                    if (i<64){
                        B[r][i+3]=d; B[r][i+4]=e; B[r][i+5]=f; B[r][i+6]=g; B[r][i+7]=h;
                    }
                }          
            }
        return;
    }
    
    if (M==48 && N==48){
        // misses=595 \approx 6*6*16
        for (i=0; i<N; i+=8)
            for (j=0; j<M; j+=8){
                for (r=0; r<8; r++){
                    a=A[i+r][j]; b=A[i+r][j+1]; c=A[i+r][j+2]; d=A[i+r][j+3];
                    e=A[i+r][j+4]; f=A[i+r][j+5]; g=A[i+r][j+6]; h=A[i+r][j+7];
                    
                    B[j+r][i]=a; B[j+r][i+1]=b; B[j+r][i+2]=c; B[j+r][i+3]=d; 
                    B[j+r][i+4]=e; B[j+r][i+5]=f; B[j+r][i+6]=g; B[j+r][i+7]=h;
                }
                for (r=0; r<8; r++)
                    for (c=0; c<r; c++){
                        d=B[j+r][i+c]; B[j+r][i+c]=B[j+c][i+r]; B[j+c][i+r]=d;
                    }
            }
        return;
    }
    
    // default
    for (i = 0; i < N; i++) {
        for (j = 0; j < M; j++) {
            B[j][i] = A[i][j];
        }
    } 
}

/* 
 * You can define additional transpose functions below. We've defined
 * a simple one below to help you get started. 
 */ 

/* 
 * trans - A simple baseline transpose function, not optimized for the cache.
 */
char trans_desc[] = "Simple row-wise scan transpose";
void trans(int M, int N, int A[N][M], int B[M][N])
{
    int i, j, tmp;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; j++) {
            tmp = A[i][j];
            B[j][i] = tmp;
        }
    }    

}


/*
 * registerFunctions - This function registers your transpose
 *     functions with the driver.  At runtime, the driver will
 *     evaluate each of the registered functions and summarize their
 *     performance. This is a handy way to experiment with different
 *     transpose strategies.
 */
void registerFunctions()
{
    /* Register your solution function */
    registerTransFunction(transpose_submit, transpose_submit_desc); 

    /* Register any additional transpose functions */
//     registerTransFunction(trans, trans_desc); 

}

/* 
 * is_transpose - This helper function checks if B is the transpose of
 *     A. You can check the correctness of your transpose by calling
 *     it before returning from the transpose function.
 */
int is_transpose(int M, int N, int A[N][M], int B[M][N])
{
    int i, j;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; ++j) {
            if (A[i][j] != B[j][i]) {
                return 0;
            }
        }
    }
    return 1;
}

