/*
FileName: Constant.cpp
Description: The Constants of 24 problem
Version:1.0
Date:08/28/2018 
*/
#include <iostream>
#include "Constant.h"


Constant* g_Constant=new Constant();