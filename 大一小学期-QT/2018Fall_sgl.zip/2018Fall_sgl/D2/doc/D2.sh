latex D2.tex

bibtex D2

latex D2.tex

latex D2.tex

dvipdf D2.dvi D2.pdf
