latex D4.tex

bibtex D4

latex D4.tex

latex D4.tex

dvipdf D4.dvi D4.pdf
