latex D3.tex

bibtex D3

latex D3.tex

latex D3.tex

dvipdf D3.dvi D3.pdf
