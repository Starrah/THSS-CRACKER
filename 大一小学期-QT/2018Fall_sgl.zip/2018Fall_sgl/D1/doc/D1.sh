latex D1.tex

bibtex D1

latex D1.tex

latex D1.tex

dvipdf D1.dvi D1.pdf
