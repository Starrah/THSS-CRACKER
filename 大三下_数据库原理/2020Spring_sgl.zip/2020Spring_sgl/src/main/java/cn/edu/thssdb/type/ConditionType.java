package cn.edu.thssdb.type;

/**
*EQ:=
*NE:<>
*GT:>
*LT:<
*GE:>=
*LE:<=
 */
public enum ConditionType {
    EQ, NE, GT, LT, GE, LE
}