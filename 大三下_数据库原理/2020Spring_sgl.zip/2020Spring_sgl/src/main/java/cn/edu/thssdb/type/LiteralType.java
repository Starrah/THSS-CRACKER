package cn.edu.thssdb.type;


public enum LiteralType {
	NUMBER, STRING, NULL
}
