package cn.edu.thssdb.type;

public enum ConstraintType {
	PRIMARY, NOTNULL
}