package cn.edu.thssdb.type;

public enum LogicType {
    AND, OR
}