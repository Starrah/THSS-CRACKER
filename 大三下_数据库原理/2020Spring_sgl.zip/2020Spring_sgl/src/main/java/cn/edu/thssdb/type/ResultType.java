package cn.edu.thssdb.type;

public enum ResultType {
    TRUE, FALSE, UNKNOWN
}
