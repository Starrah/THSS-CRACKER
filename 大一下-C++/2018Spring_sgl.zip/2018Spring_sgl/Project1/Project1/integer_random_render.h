#ifndef INTEGER_RANDOM_RENDER_H
#define INTEGER_RANDOM_RENDER_H

extern int integer_random_render(int down, int up);





#endif
