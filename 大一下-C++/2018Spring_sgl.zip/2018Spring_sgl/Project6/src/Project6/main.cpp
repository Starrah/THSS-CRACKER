#include<iostream>
#include"cp_integer.h"
#include"cp_student.h"
#include"cp_chain_double_link.h"
#include"cp_student_system.h"
using namespace std;
int main(int argv,char* argc[])
{
	cp_student_system s;
	s.mb_run();
	return 0;
}