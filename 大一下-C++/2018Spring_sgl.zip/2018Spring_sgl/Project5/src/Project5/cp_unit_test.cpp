#include<iostream>
#include<cmath>
#include"cp_unit_test.h"
using namespace std;
int cp_unit_test::compare()
{
	double b = 30303939;
	double a = abs(result - right_answer);
	if (right_answer != 0) b = abs(a / right_answer);
	if (b <= difference||a==0) return 1;
	else return 0;
}