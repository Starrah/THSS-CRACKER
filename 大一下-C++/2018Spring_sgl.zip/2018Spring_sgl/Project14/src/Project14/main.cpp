#include<iostream>
#include"cp_double_union.h"
#include"union_test.h"
int main(int argv, char* argc[])
{
	cp_double_union t;
	t.main_section();
	union_test();
	return 0;
}