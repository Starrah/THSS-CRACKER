#ifndef UNION_TEST_H
#define UNION_TEST_H

extern void union_test();

#endif
