#include"stdafx.h"
#include"cp_point.h"
#include<iostream>
void cp_point::set(double a,double b)
{
	x = a; y = b;
}