#include<iostream>
#include"cp_student.h"
#include"cp_student_list.h"
#include"cp_integer.h"
using namespace std;
int main(int argv, char* argc[])
{
	cp_student_list l;
	l.main_control();
	return 0;
}